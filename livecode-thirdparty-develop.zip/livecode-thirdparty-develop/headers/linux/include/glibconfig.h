#if defined(_LINUX) || defined(_LINUX_DESKTOP) || defined(_LINUX_SERVER)
#include "glibconfig.linux.h"
#else
#error glibconfig.h not present for this platform
#endif
