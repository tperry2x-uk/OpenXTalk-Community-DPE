# Fix a crash when interacting with popups created by widgets
