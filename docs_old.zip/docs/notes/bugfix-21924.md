# Fix memory leak when choosing popup menu item on macOS
