# Make sure `the machine` can distinguish between iOS device and simulator 
