# Remove selection artefacts when handles are drawn outside of parent group rect
