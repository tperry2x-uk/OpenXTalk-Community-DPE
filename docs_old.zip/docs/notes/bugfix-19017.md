# Fix crash when deleting object which is being moved

