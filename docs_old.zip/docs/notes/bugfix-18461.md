# Make sure iOS 10 simulator can be launched
