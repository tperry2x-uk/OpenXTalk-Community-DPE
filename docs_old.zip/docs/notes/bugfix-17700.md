# Fix Windows player not pausing when in edit mode
