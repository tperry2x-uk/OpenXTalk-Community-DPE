# Fix a crash when closing a stack with substacks still open
