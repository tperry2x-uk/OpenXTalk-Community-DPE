# Selected objects act as though they are on the top layer

The selection handles are now drawn over the top layer, and the selected
objects are checked first for mouse focus to enable resizing and moving
of selected objects that are underneath others.