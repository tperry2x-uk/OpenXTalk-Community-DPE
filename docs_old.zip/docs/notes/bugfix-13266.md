# Ensure option menu works on Android
