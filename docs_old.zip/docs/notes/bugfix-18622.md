# Ensure empty maps to empty lists when calling LCB library handlers
