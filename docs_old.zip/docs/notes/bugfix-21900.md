# Fix crash on iOS when calling mobileComposeMail with an attachment without data  
