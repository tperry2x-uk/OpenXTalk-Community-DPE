# Fix regression to watching global variables
