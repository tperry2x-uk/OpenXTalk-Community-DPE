# Message box does not find handlers in behaviors

