# Added missing parantheses for revIsSpeaking()
