# Dictionary entry for htmlText is missing some tags
