# Deploy 64-bit Windows standalones

You can now deploy 64-bit standalones for Windows. The `Standalone Settings`
dialog now has a `Windows x86` and a `Windows x86_64` checkbox allowing you to
choose to build either or both 32-bit and 64-bit executables.
