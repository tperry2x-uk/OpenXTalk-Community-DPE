# Ensure play command can play a remote auriofile on iOS
