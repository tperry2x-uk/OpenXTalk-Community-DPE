# Fix crash which may occur when selected objects are deleted
