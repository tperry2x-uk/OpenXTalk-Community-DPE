# Correct code example in documentation for rawClipboardData
