#  [Dict] mobileControlGet(myPlayer, "duration") is supported on Android
