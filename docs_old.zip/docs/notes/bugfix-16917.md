# Fix other widgets failing to render on Android if browser widget is used
