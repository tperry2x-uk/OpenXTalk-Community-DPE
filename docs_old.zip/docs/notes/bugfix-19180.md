# Crash when cloning an empty MCObjectPropertySet
