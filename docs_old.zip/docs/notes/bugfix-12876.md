# Ensure the IDE can be launched when the installer finishes
