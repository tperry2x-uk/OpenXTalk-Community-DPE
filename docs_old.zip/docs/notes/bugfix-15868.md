# HTML5: 'the mouseloc' always returns 0,0
