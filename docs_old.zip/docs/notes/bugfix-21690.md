# Fix crash when clicking on the magnify palette and a non-paint tool is selected
