# Make sure LiveCode doesn't keep open handles to images.

