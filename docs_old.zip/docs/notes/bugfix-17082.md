# The engine will no longer potentially crash on exit on Windows.
