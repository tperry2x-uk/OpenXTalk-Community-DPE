# Fix rendering of rotated text on Linux
