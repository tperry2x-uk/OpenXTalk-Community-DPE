# Fix CEF crash on Linux when using browser widget
