# Fix a crash when dragging onto a backdrop on OSX

