# Fixed syntax errors examples in the httpdStart and httpdResponse dictionary entries
