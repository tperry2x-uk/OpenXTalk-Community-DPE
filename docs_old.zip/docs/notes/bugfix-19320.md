# Fix SVG parsing of 'a' instruction
