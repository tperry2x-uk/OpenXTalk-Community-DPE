# Ensure no word "Standalone" is appended to the standalone name when building a Linux 64 standalone
