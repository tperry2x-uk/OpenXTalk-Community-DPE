# Fix crash when ungrouping a group before calling quit
