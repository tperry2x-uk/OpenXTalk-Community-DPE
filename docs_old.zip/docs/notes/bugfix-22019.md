# Fix several memory leaks occurring in use of specific field features
