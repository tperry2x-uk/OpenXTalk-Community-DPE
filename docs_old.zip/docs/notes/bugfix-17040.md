# Clean up temporary file during HTML5 standalone deployment
