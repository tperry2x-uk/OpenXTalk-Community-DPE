# Allow brush, spray and eraser properties to use image ids > 65535

