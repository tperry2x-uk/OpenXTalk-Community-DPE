# Fix memory leak when using filter command
