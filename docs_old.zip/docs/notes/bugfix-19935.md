# Made various improvements to the show and hide dictionary entries
