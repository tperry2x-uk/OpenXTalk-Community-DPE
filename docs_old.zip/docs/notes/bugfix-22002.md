# Fix memory leak when setting numberFormat properties

