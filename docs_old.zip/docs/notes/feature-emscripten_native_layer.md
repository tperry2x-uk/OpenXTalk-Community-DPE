# HTML5 Native Layer

Support has been added for widgets to use HTML5 elements as native layers.

The built-in emscripten module (com.livecode.emscripten) has been added 
to provide useful functions for interacting with JavaScript within the
browser, and to convert JavaScript objects to pointers suitable for setting
as the widget's native layer.
