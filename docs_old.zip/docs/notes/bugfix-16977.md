# Fix the formattedHeight of fields being too small
