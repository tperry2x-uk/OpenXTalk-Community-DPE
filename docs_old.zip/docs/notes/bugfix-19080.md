# Do not show linking warnings when building iOS standalones
