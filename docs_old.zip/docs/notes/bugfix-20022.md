# Updated an external link to Apple Event documentation in dictionary entries regarding Apple Events.
