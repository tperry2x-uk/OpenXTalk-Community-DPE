# Fix drag select of grouped controls outside clipped rect
