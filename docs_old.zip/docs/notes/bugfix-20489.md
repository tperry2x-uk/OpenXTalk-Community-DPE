# Remove revVideoGrabber external from IDE as it can no longer be supported
