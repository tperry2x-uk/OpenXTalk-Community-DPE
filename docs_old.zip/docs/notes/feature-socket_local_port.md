# Specifying local host and port when opening a socket

When opening a socket you can now specify the local port and host the socket should use. An example of this is as follows:

    open socket from ":8080" to "10.2.1.1:8080"

See the open socket dictionary entry for full details.
