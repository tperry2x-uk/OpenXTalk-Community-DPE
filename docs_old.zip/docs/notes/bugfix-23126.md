# Marked revVideoGrabber dictionary entries as deprecated.
