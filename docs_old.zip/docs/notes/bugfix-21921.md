# Fix memory leak when redrawing non-rectangular update regions
