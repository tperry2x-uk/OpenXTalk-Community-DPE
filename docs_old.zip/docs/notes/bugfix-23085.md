# Fix visual effect rendering on Macos Big Sur
