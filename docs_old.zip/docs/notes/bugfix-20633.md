# Ensure vtab doesn't interfere with styling
