# Browser: fix incorrect browser widget rect after show / hide browser while in browse mode
