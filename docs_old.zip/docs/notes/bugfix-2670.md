# Fix strange menu item highlight on Linux

