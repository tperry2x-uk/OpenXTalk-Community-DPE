# Ensure setting the imagesource of a char to a remote image works 
