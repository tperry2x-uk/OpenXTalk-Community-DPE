# Ensure path to MacOS app icon is always resolved
