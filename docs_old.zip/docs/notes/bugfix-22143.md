# Fix interactive tutorial on Windows
