# Included mention of usePixelScaling's error throwing behaviour on Android.
