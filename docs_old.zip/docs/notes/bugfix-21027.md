# Fix android shell commands with space
