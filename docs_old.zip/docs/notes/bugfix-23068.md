# Updated release notes for how LiveCode runs on Windows
