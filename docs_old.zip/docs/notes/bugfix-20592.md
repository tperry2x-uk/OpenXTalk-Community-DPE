# Ensure iOS standalones are treated as unique by fingerprint scanning
