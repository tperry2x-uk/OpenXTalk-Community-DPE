# 'compositorType' dict entry updated to refect platform OpenGL reference
