# Segmented Control Widget displays the curvatures right if there is only one segment
