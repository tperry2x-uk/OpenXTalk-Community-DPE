# dragStart message reinstated for widgets
