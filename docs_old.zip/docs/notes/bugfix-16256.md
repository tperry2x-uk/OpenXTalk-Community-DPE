#  Crash when loading a remote image and there is no internet connection
