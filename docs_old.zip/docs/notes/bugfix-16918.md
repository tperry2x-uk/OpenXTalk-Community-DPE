# Fix a crash when scrollbars have a width of zero

