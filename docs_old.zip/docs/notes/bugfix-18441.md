# Make sure the purchaseStateUpdate callback is sent with status=complete when necessary
