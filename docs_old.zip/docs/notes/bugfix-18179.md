# Fix malformed dictionary entry for the "go" command.
