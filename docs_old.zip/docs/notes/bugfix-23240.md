# Fix IDE lockup when an execution error occurs in a modal stack
