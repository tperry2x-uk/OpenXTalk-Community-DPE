#  Standalone-Community app name is now 'LiveCode'
