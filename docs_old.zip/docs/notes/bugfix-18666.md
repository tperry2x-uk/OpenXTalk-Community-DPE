# Fix crash when find command matches text in sharedText field on non-current card
