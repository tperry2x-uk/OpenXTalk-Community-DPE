# Ensure tsNetGetStatus reports transfer status as "uploading" appropriately during POST requests
