# Ensure private handler lookups are always cached
