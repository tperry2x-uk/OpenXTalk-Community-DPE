# Fix formatting in description of stack mode property
