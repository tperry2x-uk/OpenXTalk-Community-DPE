# Improve formatting of try syntax description
