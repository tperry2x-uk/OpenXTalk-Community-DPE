# Make sure unicode characters display correctly when set htmlText in browser
