# Implement 'go visible <stack>' as an antonym to 'go invisible'
