# Fixed erratic behaviour downloading files from FTP servers
