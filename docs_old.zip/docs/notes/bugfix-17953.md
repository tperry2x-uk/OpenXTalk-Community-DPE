# Fix regression to Mac window moveStack handling
