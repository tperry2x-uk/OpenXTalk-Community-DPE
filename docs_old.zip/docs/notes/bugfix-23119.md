# Fix script editor unresponsiveness while scrolling on Macos Big Sur
