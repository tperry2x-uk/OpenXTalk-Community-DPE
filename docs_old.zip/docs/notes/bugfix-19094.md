# Ensure single-codepoint grapheme clusters are checked for font support
