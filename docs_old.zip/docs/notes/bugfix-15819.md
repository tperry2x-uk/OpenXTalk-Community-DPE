# The default install path on Linux shouldn't have " " in the name
