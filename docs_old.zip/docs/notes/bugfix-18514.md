# Make sure setting clipboarddata["html"] works as expected on Windows
