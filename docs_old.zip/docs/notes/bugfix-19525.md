# Fix SFTP connection hang when remote directory doesn't exist
