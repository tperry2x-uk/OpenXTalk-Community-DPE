# Corrected mistaken key name in Info.plist file on iOS standalone
