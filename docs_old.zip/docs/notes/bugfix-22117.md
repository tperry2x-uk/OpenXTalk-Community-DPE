# Ensure `folders()` returns empty for non-existant folder paths on Windows
