# Ensure stack with windowshape will display if setting its "visible" to true after "go invisible"
