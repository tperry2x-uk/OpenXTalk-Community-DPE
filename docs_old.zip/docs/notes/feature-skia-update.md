# Update Skia (graphics library)

This major Skia update improves both rendering quality and performance.
It also opens the door to substantial future improvements and feature
additions. In order to allow this, support for certain legacy drawing
features has had to be removed. In particular, legacy blend modes (also
known as bitmap effects) are no longer supported.

