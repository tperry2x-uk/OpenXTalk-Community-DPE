# Enable using test runner with awkward paths to engines
