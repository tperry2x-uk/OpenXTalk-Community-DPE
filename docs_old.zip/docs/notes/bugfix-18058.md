# Fix keyboard not show in landscape orientation
