# Fix browser position on Mac when shown in resized palette stack
