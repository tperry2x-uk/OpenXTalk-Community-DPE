# Fix crash on 64bit iOS devices when using a browser widget
