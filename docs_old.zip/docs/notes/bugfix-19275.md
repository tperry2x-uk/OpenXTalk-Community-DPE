# Fix Android crash when a stack is deleted shortly after switching to another stack.
