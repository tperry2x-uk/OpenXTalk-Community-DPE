# The tabStops property can't be set to a boolean
