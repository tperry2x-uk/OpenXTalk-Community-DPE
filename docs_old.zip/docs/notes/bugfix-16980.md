# Browser: fix dictionary disappearing when pointer tool selected.
