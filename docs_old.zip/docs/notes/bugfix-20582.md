# Ensure the iOS device plist has correct values for the version of Xcode and SDKs used to build the standalone
