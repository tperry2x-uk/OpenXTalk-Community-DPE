# Fix memory leak when calling self-recursive handlers having reference parameters

