# Fix crash when printing preview of card with browser widget on OSX
