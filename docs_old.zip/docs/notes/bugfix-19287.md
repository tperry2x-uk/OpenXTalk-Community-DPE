# Make sure the clickLoc is updated on mouseDown/touchEnd on mobile
