# Clear the menu object when moving from one menu to another
