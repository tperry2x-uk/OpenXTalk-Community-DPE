# Make sure "Search for Inclusions" detects correctly widget inclusions on iOS simulator
