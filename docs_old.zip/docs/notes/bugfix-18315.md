# Fix invalid Linux standalone executables

