# Fixed malformed Dictionary entry of mobileGetContactData
