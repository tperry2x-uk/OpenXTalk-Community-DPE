# Mouse messages are sometimes not sent on iOS when using sockets
