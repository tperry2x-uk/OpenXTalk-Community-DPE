# Fix the pageRanges and other field methods to use the new text metrics

