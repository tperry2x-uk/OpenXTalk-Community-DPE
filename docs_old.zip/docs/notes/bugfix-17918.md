# Make sure setting clipboarddata["text"] and clipboarddata["html"] works as expected
