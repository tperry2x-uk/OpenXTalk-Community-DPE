# Fix memory leak when using put [ into msg ] on macOS when there is no message box
