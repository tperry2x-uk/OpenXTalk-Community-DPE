# Ensure location services work when the standalone is built with the iOS 12 SDK
