# Fix memory leak when using arrayEncode with encodeVersion less than 7.0
