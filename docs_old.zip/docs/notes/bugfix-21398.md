# Do not split up .framework folders between MacOS and Resources/_MacOS folder
