# Android: fix incorrect rendering of text with negative origin coordinates
