# Clarified in the playStopped entry that it is sent when a clip plays backwards to the beginning.
