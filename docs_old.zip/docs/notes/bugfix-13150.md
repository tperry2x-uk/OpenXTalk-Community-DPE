# Ensure tabStops property docs describe relationship with indent properties
