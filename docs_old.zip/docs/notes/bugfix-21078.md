# Apply LCB android permissions to app they are included in
