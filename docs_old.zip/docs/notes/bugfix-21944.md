# Ensure menus do not remain open under some circumstances on Windows and Linux
