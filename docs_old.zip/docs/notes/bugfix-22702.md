# Add ad-hoc signature to mac standalones, to allow mac apps to be opened on MacOS Catalina
