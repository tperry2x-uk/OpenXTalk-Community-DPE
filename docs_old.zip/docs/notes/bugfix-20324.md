# Convert dropped file paths correctly on Windows
