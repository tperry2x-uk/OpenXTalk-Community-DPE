# Remove trailing NULs from text data on the Win32 clipboard

