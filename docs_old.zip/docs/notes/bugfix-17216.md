# Allow pasting images from some applications on Mac
