# Make sure botton icons are present in standalones when building for multiple platforms
