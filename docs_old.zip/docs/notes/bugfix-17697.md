# Fix player view occasionally not showing on Mac
