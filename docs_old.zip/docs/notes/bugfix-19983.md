# Ensure `put URL tUrl` does not return empty when tUrl is invalid 
