# Fix memory leaks occurring through the use of autocomplete in the IDE
