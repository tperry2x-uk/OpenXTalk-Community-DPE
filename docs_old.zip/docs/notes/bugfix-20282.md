# Ensure 'the engine folder' returns a LiveCode path on Windows
