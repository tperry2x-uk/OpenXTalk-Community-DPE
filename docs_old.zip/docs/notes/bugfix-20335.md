# Mac folder dialog missing "add folder" button
