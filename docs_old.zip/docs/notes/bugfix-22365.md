# Fix black screen on Android when navigating between cards with acceleratedRendering enabled
