# Ensure fonts work in-ui mode on Windows

