# Revert a target stack

It is now possible to revert a stack that is not the topStack, using 

	revert <stack reference>