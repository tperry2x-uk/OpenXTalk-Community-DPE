# Prevent multiple font-related crashes in HTML5 engine
