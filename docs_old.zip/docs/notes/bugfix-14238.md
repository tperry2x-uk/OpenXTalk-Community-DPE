# Ensure background pattern stays aligned in long fields
