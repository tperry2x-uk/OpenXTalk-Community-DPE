# Don't try to use the GDK clipboard in the Linux server

