# Added note that revDeleteFolder can not delete the defaultFolder
