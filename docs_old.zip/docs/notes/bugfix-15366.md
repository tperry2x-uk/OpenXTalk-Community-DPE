# Correctly update stack rectangle when moving to a different screen
