# Fix exception thrown when calling revBrowserPrint
