# Fix bug ignoring garbage values at end of repeat line
