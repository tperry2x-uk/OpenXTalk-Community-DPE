# Correct lineOffset / itemOffset mode in wholeMatches mode.

The lineOffset and itemOffset functions now work correctly in wholeMatches mode
in that they will not stop after the first occurrance of needle.
