# Ensure text is copied as unstyled on mac
