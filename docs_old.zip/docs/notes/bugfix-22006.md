# Fix memory leaks when using player on macOS
