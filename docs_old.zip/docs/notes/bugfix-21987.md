# Fix pasteboard leak on macOS
