# Fix memory leak when using send/post/execute script from LCB
