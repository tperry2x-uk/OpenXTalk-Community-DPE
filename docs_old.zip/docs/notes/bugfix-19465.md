# Change the orientation on Android when `mobileSetAllowedOrientations` does not allow the current orientation
