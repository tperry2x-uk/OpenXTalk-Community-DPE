# Ensure mobileSoundOnChannel() returns correct value on iOS
