# Resolve folder path before processing files(folder) and folders(folder)
