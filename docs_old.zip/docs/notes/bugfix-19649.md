# Correctly parse multiple bytes escaped as hex in the format function
