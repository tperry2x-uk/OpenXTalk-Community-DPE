# Fix crash in `split` command with multi-char delimiter
