# Ensure matchChunk returns the correct char positions
