# Fix encoding of svg paths containing relative commands
