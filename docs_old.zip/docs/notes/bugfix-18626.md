# Make sure the Standalone Application Settings on Windows are respected
