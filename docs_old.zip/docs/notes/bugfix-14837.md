 # tan entry in API dictionary contains typographical error. function end on line 40 was cosInDegrees instead of tanInDegrees
