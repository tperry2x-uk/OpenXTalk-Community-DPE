# Make sure drag-drop works from all applications on Mac
