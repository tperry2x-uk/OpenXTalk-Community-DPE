# HTML5: Implement specialFolderPath() function
