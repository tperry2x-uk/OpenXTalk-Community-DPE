# Add support for merging activity attributes in Android Manifest Merging mechanism
