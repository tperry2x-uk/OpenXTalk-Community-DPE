# New keyboardType field property

A new property has been added to fields to control the keyboard type displayed
on the mobile keyboard.