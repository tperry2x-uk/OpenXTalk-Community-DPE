# Android: fix incorrect values for mouseloc, mouseV, mouseH on Android
