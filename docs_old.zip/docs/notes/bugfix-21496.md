# Ensure emscripten aux stacks are loaded on startup
