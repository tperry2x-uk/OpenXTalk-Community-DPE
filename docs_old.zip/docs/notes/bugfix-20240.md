# Fix text selection occasionally not being contiguous
