# Fix memory leaks when releasing loaded LCB modules and instances
