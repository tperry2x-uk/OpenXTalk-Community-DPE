# Restore the ability to dismiss menus by clicking outside them

