# Mark the copyResource function as deprecated
