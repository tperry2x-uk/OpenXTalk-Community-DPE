# Fixed bug causing crash when using chunks of the type 'the last char to -4 of "fdwbfdf"'
