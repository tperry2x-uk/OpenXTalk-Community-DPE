# Ensure the formattedRect of line N always returns the correct result

