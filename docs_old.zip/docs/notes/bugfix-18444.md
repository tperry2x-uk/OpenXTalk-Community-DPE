# Make sure put cookie with empty value works as expected 
