# Fix a hang when pasting from LiveCode into WordPad on Windows

