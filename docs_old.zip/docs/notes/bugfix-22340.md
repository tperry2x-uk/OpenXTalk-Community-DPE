# Added a note to the URLEncode entry that non-ASCII input must have first been put through textEncode
