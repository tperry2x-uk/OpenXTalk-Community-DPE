---
version: 8.0.0-dp-5
---
# Fix Android crash when calling libffi closures
