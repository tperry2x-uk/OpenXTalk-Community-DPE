# Ensure bundled Android externals are available on Windows and Linux
