# Set default timeout in tsNet to prevent app hangs when Internet connection drops
