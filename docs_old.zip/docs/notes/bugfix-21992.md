# Fix memory leaks when sorting cards, fields, or object selection
