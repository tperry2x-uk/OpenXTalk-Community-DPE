# Fix memory leak in 'the processor' function
