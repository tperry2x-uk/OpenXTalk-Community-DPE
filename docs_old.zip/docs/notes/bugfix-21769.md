# Added new function iphoneDeviceModel() that returns the machine name of the iOS device the app is running on
