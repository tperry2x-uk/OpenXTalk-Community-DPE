# Fix memory leak when updating listBehavior fields in some cases
