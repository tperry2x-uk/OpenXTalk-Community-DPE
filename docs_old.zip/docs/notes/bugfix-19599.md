# Ensure correct source rect is used for 'print card from lt to rb'
