# An issue causing `$_POST_RAW` on Windows to not be set for large uploads has been fixed.
