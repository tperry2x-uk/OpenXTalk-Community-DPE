# Ensure mobilePickPhoto with width and height params works on older Android versions
