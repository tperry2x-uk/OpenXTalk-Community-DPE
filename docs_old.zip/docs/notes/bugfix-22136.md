# Show appropriate message when standalone building is canceled
