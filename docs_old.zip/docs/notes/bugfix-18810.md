# Fix a crash when cutting controls

