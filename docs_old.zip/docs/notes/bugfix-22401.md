# Ensure the iOS time picker always returns the displayed (rounded) time 
