# Ensure widget mouse events work after dragging a widget
