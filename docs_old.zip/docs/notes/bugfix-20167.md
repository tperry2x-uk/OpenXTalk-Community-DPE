# Fix capitalization of menu item "Hide Others" on Mac
