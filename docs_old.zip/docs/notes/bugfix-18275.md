# Enable sqlite FTS5 feature
