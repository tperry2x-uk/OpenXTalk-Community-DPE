# Fix crash when using several android native fields
