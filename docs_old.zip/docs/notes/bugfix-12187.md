# Make sure keyboardActivated/keyboardDeactivated messages are sent when the status bar is hidden on Android
