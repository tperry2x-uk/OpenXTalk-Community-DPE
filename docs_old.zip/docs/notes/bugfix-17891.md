# Reset the m_was_licensed instance variable to true before calls to an external's handler
