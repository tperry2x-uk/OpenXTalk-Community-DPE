# Fixed crash on iOS 10 when trying to read local notifications
