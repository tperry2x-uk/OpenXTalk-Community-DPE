# Allow socket to send broadcast packet on Android.
