# Syntax: mouseUp mouseButtonNumber
