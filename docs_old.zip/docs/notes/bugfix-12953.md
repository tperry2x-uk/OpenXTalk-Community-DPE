# Last character of dragdata["files"] is no longer cut off
