# Fix crash when using RSA encryption and revsecurity is not loaded
