# Fix memory leaks when using clipboard functions
