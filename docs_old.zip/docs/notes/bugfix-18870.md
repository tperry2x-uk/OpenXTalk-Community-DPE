# Fix crash caused by calling tsNetGetSync() repeatedly against the same URL
