# Fix graphical artefacts when reshaping polygon graphics while selected
