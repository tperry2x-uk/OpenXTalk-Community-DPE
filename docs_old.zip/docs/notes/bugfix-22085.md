# Ensure dashes offset drawing library opcode works correctly
