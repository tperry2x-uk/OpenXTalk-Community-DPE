# Fix crash on iOS when calling `play empty` followed by `play path/to/audio/file`
