# Added a note to the URLDecode entry that non-ASCII output must be put through textDecode
