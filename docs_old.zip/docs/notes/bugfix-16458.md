# Fix fetching data from the OSX raw clipboard that is identified by a Pboard type or OSType

