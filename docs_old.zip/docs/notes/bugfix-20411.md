# Fix crash when using Obj-C FFI on iOS
