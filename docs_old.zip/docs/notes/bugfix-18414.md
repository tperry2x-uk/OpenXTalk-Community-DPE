# Make sure resources are copied in the app bundle on iOS 10 simulator
