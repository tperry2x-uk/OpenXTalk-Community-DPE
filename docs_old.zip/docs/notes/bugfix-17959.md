# Fix a crash on iOS 9 when rendering subviews
