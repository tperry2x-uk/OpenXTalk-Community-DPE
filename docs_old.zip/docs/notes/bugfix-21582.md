# Fix crash and stack corruption when opening a stack that has a colorswatch widget
