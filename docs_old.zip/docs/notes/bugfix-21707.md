# Ensure DataGrids with decimal keys can scroll
