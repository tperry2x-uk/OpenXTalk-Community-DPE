# Use name values rather than string values for variable initializers
