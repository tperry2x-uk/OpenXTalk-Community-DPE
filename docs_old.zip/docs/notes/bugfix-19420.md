# Fix crash on startup when resuming android app after quit
