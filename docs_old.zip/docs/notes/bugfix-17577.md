#  Make sure we can set the hilitedItemName property of the navBar widget
