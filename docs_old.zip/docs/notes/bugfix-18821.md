# Report all LCB stack frames in LCS error info
