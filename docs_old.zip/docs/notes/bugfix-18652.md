# Fix occasional crash when getting the clipboarddata["text"] on Windows.
