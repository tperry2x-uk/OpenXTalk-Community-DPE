# Fix formatting in scrollbarWidth property documentation
