# Fix crash due to invalid object in event queue
