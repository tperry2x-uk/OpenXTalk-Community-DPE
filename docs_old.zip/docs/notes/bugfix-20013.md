# Database type passed to revOpenDatabase should be case insensitive
