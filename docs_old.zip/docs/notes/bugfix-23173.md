# Fix rectangle border inset too much when printing on Windows or to PDF
