# Improve shift+click behavior of text selection in XPDF
