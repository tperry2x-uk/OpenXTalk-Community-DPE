# Improve accuracy of "lock clipboard" documentatino
