# Fix format of mobileControlDo entry
