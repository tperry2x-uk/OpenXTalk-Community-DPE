# Restore legacy behavior when parsing hexadecimal constants

