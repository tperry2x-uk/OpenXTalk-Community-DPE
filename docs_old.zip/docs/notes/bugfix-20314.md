# Amended the HTMLText dictionary entry to say that r,g,b is also an acceptable HTML-style color definition.
