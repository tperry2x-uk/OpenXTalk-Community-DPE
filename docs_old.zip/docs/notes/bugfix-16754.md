#  Field line spacing is now correct when displaying an image via imageSource
