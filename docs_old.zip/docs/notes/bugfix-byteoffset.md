# Fixed bug causing byteOffset to behave incorectly in certain cases
