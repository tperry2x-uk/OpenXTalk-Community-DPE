# Ensure extensions' resource folders are available in standalones
