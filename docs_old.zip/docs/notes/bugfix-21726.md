# Fix crash when using "inf" in mathematical ops 
