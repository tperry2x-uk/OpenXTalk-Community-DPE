# Fix performance regression in replaceText
