# Prevent crashes on memory exhaustion
