# Fix crash when deleting an object when a socket has a reference to a deleted object
