# Improve native string performance by using non-folding operations whenever possible
