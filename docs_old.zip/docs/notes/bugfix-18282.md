# Fix a crash after deleting a shared background group
