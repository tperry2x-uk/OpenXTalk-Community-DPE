# Fix memory leaks when splitting strings in specific cases

