# Ensure cards with objects on can be deleted
