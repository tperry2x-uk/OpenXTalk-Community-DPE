# Fix crash running standalones on some Android devices (Android version < 4.2)
