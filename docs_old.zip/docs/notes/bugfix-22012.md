# Fix memory leak when using LCB's log command on desktop platforms
