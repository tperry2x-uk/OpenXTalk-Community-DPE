# Fix memory leak when using filter on unicode strings
