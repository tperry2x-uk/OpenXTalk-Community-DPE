# Fix local-ref overflow when repeatedly calling Java from LCB on older Android OSes
