# Server returns 'ELF' over HTTP
