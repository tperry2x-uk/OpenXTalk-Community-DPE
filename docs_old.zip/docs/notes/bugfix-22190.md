# Ensure setting the spaceAbove does not change the existing value of spaceBelow property
