# Fix bad example of using the menuName property
