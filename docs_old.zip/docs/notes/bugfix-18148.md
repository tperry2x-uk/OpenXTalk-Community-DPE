# Fix inline example of using imageData to get color channels
