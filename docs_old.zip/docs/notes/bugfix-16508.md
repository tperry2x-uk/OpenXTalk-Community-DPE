# Update documentation for behavior property
