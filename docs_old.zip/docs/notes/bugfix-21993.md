# Make name and string values more memory efficient
