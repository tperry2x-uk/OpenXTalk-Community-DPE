# Make sure printSettings are set correctly
