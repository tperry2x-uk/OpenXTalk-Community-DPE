# Eliminate 'Invalid TIFF' (console) warning on startup on macOS

