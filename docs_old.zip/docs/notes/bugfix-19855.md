# Added cross reference to trueWord to the word entry in the dictionary.
