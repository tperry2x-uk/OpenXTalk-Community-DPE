# Ensure replace works correctly with decomposed characters
