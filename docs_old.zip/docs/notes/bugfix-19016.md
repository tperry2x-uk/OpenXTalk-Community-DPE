# Ensure printing a field with vGrid enabled does not print black rectangles on Windows
