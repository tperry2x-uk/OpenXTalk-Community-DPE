# Prevent crash when using undo to bring back removed controls
