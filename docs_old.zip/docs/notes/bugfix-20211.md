# Fix Mac player crash when setting filename multiple times
