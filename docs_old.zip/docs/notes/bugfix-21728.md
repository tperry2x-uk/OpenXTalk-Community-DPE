# Ensure one can set the filename of an image to a relative path
