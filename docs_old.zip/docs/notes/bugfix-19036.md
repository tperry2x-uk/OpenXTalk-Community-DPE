# Fix incorrect local file path when setting url of browser widget on Android.
