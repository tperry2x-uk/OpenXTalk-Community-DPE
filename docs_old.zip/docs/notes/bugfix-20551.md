# Android: Update Notification module to compile against API 23
