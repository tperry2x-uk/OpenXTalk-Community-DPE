# Updated print command docs ensuring parameters topLeft and bottomRight were used consistently.
