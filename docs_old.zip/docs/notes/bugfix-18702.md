# Ensure Alt+<number_sequence> does produce unicode characters on Windows
