# Fix memory leak when rendering gradients where the quality is set to "good"
