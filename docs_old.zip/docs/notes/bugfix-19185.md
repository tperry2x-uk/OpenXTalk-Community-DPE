# Ensure the dragData["private"] isn't cleared during a drag
