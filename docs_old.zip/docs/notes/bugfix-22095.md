# Fix input of alt+key combination characters in HTML5 standalones

*Note* To allow typing of characters into a field using alt+key combinations it has been necessary to turn off detection of the alt key state, as there is no current reliable means to determine if the alt key is required to type the combination character (and can be ignored) or not.