# Fix memory leak when using filter elements of array
