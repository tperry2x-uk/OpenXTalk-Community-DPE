# Make pasting from MS Paint work
