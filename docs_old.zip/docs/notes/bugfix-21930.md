# Fix memory leak in GetVariableEx and GetVariableEx external V0 functions
