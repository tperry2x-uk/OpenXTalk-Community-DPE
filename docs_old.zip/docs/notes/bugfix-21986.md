# Fix benign leak of backdrop window on engine shutdown on macOS
