# [[HTML5 ]] Fix detection of mouseevents when cursor leaves window bounds.
