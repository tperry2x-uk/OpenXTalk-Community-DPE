# Curly brace subscripts are now a syntax error

Previously, it was possible to use curly brackets or braces `{}`
instead of square brackets `[]` in array and custom property
syntax. This was an undocumented and unknown feature to most users.

Using `{}` to subscript arrays is now a script syntax error.  Curly
brackets have been reserved for future use.
