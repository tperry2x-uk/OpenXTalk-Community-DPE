# Fix memory leak when setting widget properties in some cases
