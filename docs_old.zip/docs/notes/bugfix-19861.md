# Fix crash on startup on Linux when RGBA is not supported
