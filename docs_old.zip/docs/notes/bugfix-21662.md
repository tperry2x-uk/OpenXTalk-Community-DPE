# Fix crash when setting the scrollbar to false while scrolling
