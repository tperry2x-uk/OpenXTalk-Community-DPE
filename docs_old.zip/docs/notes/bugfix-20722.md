# Update launch URL command note for Android.
