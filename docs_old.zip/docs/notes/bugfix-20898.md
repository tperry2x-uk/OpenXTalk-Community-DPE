# Fix crash when converting from utf16 with revDataFromQuery
