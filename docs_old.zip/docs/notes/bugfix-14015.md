urldecode and urlencode broken with Unicode characters
