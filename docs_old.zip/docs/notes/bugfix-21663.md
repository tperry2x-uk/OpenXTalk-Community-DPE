# Fix error when building an Android standalone and the TimeZone library is included
