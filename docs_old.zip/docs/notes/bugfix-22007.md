# Fix memory leaks when using menus on macOS
