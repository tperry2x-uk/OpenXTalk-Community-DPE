# Fix crash when using HTML file input dialog in browser widget
