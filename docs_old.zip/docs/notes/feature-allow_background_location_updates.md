# Allow background location updates

A new command `iphoneAllowBackgroundLocationUpdates` has been added, which can be used to
allow/disallow location updates when the app is suspended. This command has an effect only
if "Location Update" is checked in the "Background Execution" section in the iOS standalone
settings. 
