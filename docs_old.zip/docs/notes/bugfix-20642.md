# Fix crash when undoing a group deletion
