# Fix crash while loading Unicode paragraph data from legacy stack files
