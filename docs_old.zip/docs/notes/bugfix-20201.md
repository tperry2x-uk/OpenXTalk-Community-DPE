# Ensure `the controlNames` does not return numbers instead of names for controls in groups
