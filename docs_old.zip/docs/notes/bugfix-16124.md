---
version: 8.0.0-dp-7
---
# char chunk gives unexpected results when initial index is out of range
