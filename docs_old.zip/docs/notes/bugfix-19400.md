# Unmangle java module docs
