# Support mobilePickPhoto() maximum width and height settings on Android
