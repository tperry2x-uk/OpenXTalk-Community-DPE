# The "startup" message is sent to the first card of the initial stack
