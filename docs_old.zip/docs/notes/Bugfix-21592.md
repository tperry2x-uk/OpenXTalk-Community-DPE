# Corrected several typos in the revOpenDatabase dictionary entry.
