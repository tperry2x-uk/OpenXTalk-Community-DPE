# Fix some images rendering as black in recent macOS versions
