# Fix a crash on Linux servers without libPango available

