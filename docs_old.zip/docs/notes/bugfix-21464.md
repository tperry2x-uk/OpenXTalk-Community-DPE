# mobileSetKeyboardReturnKey on android

The mobileSetKeyboardReturnKey is now supported on android and the iphoneSetKeyboardReturnKey
synonym is now deprecated