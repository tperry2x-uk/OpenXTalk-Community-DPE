# Include the correct version's release notes in the installer
