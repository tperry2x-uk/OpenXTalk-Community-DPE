#  Remove 32-bit server dependency on libX11.so.6
