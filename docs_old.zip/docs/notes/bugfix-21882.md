# Fix video view closing when player control is grouped / ungrouped
