# Ensure datagrids are re-initialised after deploy
