# Fix window redraw issue on MacOS X when making changes to a card immediately after switching to it
