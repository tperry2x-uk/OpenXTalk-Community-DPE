# Fix a crash when drag-selecting controls

