# Fix crash when deleting the target object in a front or back script.
