# Ensure the Mac autoupdater is 64-bit
