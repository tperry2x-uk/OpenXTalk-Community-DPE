# Ensure resources are placed in the correct folder when building Mac standalones on a Windows machine
