# Fix memory leaks in LCB 'number of chars in' and 'is among the chars of' operators

