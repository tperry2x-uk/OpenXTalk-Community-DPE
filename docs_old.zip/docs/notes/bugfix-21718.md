# Added note about calling mobileSensorAvailable to the mobileCurrentLocation entry
