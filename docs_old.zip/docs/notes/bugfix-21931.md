# Fix memory leak when executing send or call commands
