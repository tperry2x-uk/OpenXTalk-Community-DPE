# Fix DNS resolver issue causing connection hang when using tsNet on Linux
