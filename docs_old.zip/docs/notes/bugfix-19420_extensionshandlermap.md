# Android: Fix crash on relaunch when calling extension handler from script
