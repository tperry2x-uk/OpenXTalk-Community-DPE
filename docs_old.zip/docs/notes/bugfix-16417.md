# Standalone builder isn't including browser framework files
