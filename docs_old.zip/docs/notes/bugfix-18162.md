# Ensure Mac universal externals are found correctly
