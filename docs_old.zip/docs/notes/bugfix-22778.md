# Added deprecation note to play videoClip
