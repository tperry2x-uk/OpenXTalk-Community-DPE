# Support resizing stacks for orientation changes in fullscreen modes

A new mobile command `mobileSetFullScreenRectForOrientations` has been
implemented to allow stacks that use the `fullscreenMode` property to
be resized when the device orientation changes.
