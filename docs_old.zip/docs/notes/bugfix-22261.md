# Fix error when building an Android standalone on Windows and the barcode scanner widget is included
