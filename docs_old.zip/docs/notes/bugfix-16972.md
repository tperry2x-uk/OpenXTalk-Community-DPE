#  Fix crash when accessing photo lib on iOS
