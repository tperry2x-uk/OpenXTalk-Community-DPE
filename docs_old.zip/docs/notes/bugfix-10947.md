# Fix hypercard-compatibility dynamic path behavior
