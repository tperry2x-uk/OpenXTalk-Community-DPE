# Fix crash on execution error in ask dialog
