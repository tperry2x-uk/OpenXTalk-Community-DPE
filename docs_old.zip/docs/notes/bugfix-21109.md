# Ensure when setting `the fullClipboardData["text"]` to only clear the clipboard if it contains styled text and do not clear private data
