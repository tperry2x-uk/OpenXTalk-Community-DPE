# Standard help cursor now works on Windows

If the standard cursors are not overriden on Windows, then they now work correctly.
