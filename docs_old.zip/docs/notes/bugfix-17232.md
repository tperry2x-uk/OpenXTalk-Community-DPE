# Correct searching for a single character in a unicode string
