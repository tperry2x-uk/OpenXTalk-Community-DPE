# Add support for upper and lower case field shortcuts on Mac
