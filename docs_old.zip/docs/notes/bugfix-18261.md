# Fixed crash on 64-bit iOS simulator when tsNet/Internet lib is included in the standalone
