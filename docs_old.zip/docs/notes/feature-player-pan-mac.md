# New stereo panning properties added to MacOSX Player object

leftBalance: control the volume of the left stereo channel.
rightBalance: control the volume of the right stereo channel.
audioPan: pan audio from one stereo channel to another.

Note: these properties currently require media files to have stereo audio tracks.
There will be no effect on mono or surround-sound formats.
