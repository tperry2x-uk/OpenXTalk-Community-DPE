# Removed unwanted HTML entities from the menu dictionary entry
