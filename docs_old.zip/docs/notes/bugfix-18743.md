# Fix missing cross-references in "keys" dictionary entry
