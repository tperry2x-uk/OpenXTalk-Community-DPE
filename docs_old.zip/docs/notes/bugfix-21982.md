# Ensure `the printersettings` always return the user's choice
