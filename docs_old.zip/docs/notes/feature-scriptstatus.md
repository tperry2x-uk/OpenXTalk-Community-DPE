# A new scriptStatus of object property has been implemented

Use `the scriptStatus of <object>` to determine the status of the
last time the script property was set or the script was compiled
when the stack was opened.
